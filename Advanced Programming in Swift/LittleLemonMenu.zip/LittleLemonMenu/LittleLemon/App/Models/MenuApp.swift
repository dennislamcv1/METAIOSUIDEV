//
//  MenuApp.swift
//  LittleLemon
//
//  Created by Hossein Payami
//

import SwiftUI

@main
struct MenuApp: App {
    var body: some Scene {
        WindowGroup {
            MenuView()
        }
    }
}
