//
//  MenuCategory.swift
//  LittleLemon
//
//  Created by Hossein Payami
//

import Foundation

enum MenuCategory: String {
    case food, drink, dessert
}
