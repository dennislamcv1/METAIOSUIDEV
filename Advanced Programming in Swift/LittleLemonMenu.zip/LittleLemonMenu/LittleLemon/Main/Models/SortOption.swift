//
//  SortOption.swift
//  LittleLemon
//
//  Created by Hossein Payami
//

import Foundation

enum SortOption {
    case popularity
    case price
    case alphabetical
}
